#ifndef __KEY_H
#define __KEY_H

#include <stdint.h>

extern void Key_Init(void) ;
extern uint32_t IsKeyDown(void) ;

#endif
