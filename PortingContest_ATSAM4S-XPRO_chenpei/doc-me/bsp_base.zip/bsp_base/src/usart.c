#include "SAM4S.h"                        /* SAM4S definitions                */
#include "usart.h"



void Uart1_Init(void) 
{
	uint32_t ul_sr;
	
  PMC->PMC_WPMR = 0x504D4300;             /* Disable write protect            */


  PMC->PMC_PCER0 = ((1UL << ID_PIOB  ) |  /* enable PIOB   clock              */
                    (1UL << ID_UART1)  );/* enable USART1 clock              */  

  /* Configure UART1 Pins (PB3 = TX, PB2 = RX). */
  PIOB->PIO_IDR        =  (PIO_PB2A_URXD1 | PIO_PB3A_UTXD1);
	
	ul_sr = PIOB->PIO_ABCDSR[0];
	PIOB->PIO_ABCDSR[0] &= (~(PIO_PB2A_URXD1 | PIO_PB3A_UTXD1) & ul_sr);
	ul_sr = PIOB->PIO_ABCDSR[1];
	PIOB->PIO_ABCDSR[1] &= (~(PIO_PB2A_URXD1 | PIO_PB3A_UTXD1) & ul_sr);

  PIOB->PIO_PDR        =  (PIO_PB2A_URXD1 | PIO_PB3A_UTXD1);
	PIOB->PIO_PUDR       =  (PIO_PB2A_URXD1 | PIO_PB3A_UTXD1);


  /* Configure UART1 for 115200 baud. */
  UART1->UART_CR   = (UART_CR_RSTRX | UART_CR_RSTTX) |
                     (UART_CR_RXDIS | UART_CR_TXDIS);
	UART1->UART_BRGR = (SystemCoreClock / 115200) / 16;
  UART1->UART_MR   =  (0x4u <<  9);        /* (UART) No Parity                 */
  UART1->UART_CR   = UART_CR_RXEN | UART_CR_TXEN;
	
	//interrupt
	UART1->UART_IER = UART_IER_RXRDY;
	NVIC_EnableIRQ(UART1_IRQn);

  PMC->PMC_WPMR = 0x504D4301;             /* Enable write protect             */
}

void Uart1_PutChar(uint8_t c) 
{
	while (!(UART1->UART_SR & UART_SR_TXRDY));
	UART1->UART_THR = c;
}

uint8_t Uart1_GetChar(void) 
{
    while((UART1->UART_SR & UART_SR_RXRDY) == 0);
    return UART1->UART_RHR;
}

static char _buffer[256];
void Uart1_Printf(char* fmt, ...)
{
	int i;
	va_list ap;
	va_start(ap, fmt);
	vsprintf(_buffer, fmt, ap);
	va_end(ap);

	for (i = 0; _buffer[i] != '\0'; i++)
	{
		Uart1_PutChar(_buffer[i]);
	}
}

void UART1_IRQHandler() 
{
	uint32_t dw_status = UART1->UART_SR;//uart_get_status

	if(dw_status & UART_SR_RXRDY) 
	{
		uint8_t received_byte;
		received_byte = Uart1_GetChar();
		Uart1_PutChar(received_byte);
	}
}
