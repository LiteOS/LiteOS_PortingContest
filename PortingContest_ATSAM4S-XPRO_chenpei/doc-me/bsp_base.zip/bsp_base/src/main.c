#include "sam4s.h"
#include "systick.h"
#include "led.h"
#include "key.h"
#include "usart.h"

int main(void)
{
	SystemInit();
	SystemCoreClockUpdate();
	SysTick_Config(SystemCoreClock/1000); //1ms
	
	LED_Init();
	Key_Init();
	Uart1_Init();
	
	while(1)
	{
//		LED_On();
//		delay_ms(500);
//		LED_Off();
//		delay_ms(500);
		
		if(IsKeyDown())
		{
			LED_On();
			Uart1_Printf("KeyDown%d\r\n", 666);
		}
		else
		{
			LED_Off();
			Uart1_Printf("KeyUp%d\r\n", 888);
		}
		delay_ms(500);
	}
}


