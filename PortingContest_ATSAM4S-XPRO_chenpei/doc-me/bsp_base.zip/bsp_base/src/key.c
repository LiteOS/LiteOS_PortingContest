#include "sam4s.h" 
#include "systick.h"
#include "key.h" 


void Key_Init(void) 
{
  PMC->PMC_WPMR = 0x504D4300;             /* Disable write protect            */

  PMC->PMC_PCER0 = (1UL << ID_PIOA);      /* enable clock for push button     */

  PIOA->PIO_PUER =
  PIOA->PIO_IDR  =
  PIOA->PIO_ODR  =
  PIOA->PIO_PER  = (PIO_PA2);             /* Setup PA2 for user button SW0    */

  PMC->PMC_WPMR = 0x504D4301;             /* Enable write protect             */
}

uint32_t IsKeyDown(void) 
{
  if (~(PIOA->PIO_PDSR) & (PIO_PA2)) 
	{
    return 1;
  }
	else
		return 0;
}

