#ifndef __UART1_H
#define __UART1_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdarg.h>

extern void Uart1_Init(void);
extern void Uart1_PutChar(uint8_t c);
extern uint8_t Uart1_GetChar(void);
extern void Uart1_Printf(char* fmt, ...);

#endif
