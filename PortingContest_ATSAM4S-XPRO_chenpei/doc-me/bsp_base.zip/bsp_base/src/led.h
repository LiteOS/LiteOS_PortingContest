#ifndef __LED_H
#define __LED_H

#include <stdint.h>


extern void LED_Init(void);
extern void LED_On(void);
extern void LED_Off(void);


#endif /* __LED_H */
