#ifndef __SYSTICK_H
#define __SYSTICK_H

#include <stdint.h>

extern void delay_ms(unsigned int n);

#endif
